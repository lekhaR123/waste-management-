import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Home, 
  Truck, 
  Calendar, 
  AlertCircle, 
  BarChart3, 
  Settings, 
  Search, 
  Plus, 
  Database as DbIcon,
  Recycle,
  MapPin,
  CreditCard,
  ShieldCheck,
  ChevronRight,
  Menu,
  X,
  LogOut,
  User,
  Clock,
  CheckCircle2,
  Filter
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface User {
  id: number;
  name: string;
  role: string;
  login_id: string;
  email?: string;
  phone?: string;
}

interface Stat {
  count?: number;
  total?: number;
}

interface DashboardStats {
  citizens: Stat;
  households: Stat;
  bins: Stat;
  vehicles: Stat;
  complaints: Stat;
  totalWaste: Stat;
}

// --- Components ---

const SidebarItem = ({ icon: Icon, label, active, onClick, color, collapsed }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center space-x-3 px-4 py-3 rounded-xl transition-all duration-200 ${
      active 
        ? `bg-white shadow-lg text-gray-900 font-bold` 
        : `text-white/70 hover:bg-white/10 hover:text-white`
    }`}
  >
    <div className={`p-2 rounded-lg ${active ? color : 'bg-transparent'}`}>
      <Icon size={20} className={active ? 'text-white' : ''} />
    </div>
    {!collapsed && <span className="text-sm tracking-wide">{label}</span>}
  </button>
);

const Card = ({ title, value, icon: Icon, color, delay = 0 }: any) => (
  <motion.div
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className="bg-white p-6 rounded-3xl shadow-sm border border-gray-100 flex items-center justify-between overflow-hidden relative group"
  >
    <div className={`absolute -right-4 -bottom-4 w-24 h-24 rounded-full opacity-10 group-hover:scale-110 transition-transform duration-500 ${color}`} />
    <div>
      <p className="text-gray-500 text-sm font-medium mb-1">{title}</p>
      <h3 className="text-3xl font-bold text-gray-900">{value}</h3>
    </div>
    <div className={`p-4 rounded-2xl ${color} text-white shadow-lg`}>
      <Icon size={24} />
    </div>
  </motion.div>
);

const Table = ({ headers, data, renderRow }: any) => (
  <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
    <div className="overflow-x-auto">
      <table className="w-full text-left border-collapse">
        <thead>
          <tr className="bg-gray-50/50 border-b border-gray-100">
            {headers.map((h: string) => (
              <th key={h} className="px-6 py-4 text-xs font-bold text-gray-400 uppercase tracking-wider">{h}</th>
            ))}
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {data.length > 0 ? (
            data.map((item: any, idx: number) => renderRow(item, idx))
          ) : (
            <tr>
              <td colSpan={headers.length} className="px-6 py-10 text-center text-gray-400 italic">No records found</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  </div>
);

const Login = ({ onLogin }: { onLogin: (user: User) => void }) => {
  const [isSignup, setIsSignup] = useState(false);
  const [formData, setFormData] = useState({
    login_id: '',
    password: '',
    name: '',
    email: '',
    phone: ''
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      const endpoint = isSignup ? '/api/signup' : '/api/login';
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      const data = await res.json();
      if (data.success) {
        onLogin(data.user);
      } else {
        setError(data.error || 'Authentication failed');
      }
    } catch (err) {
      setError('Connection failed');
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-600 via-emerald-600 to-teal-700 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="bg-white/95 backdrop-blur-xl p-10 rounded-[40px] shadow-2xl w-full max-w-md border border-white/20"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="bg-emerald-500 p-4 rounded-3xl shadow-xl shadow-emerald-500/20 mb-4">
            <Recycle className="text-white" size={40} />
          </div>
          <h1 className="text-3xl font-black text-gray-900 tracking-tighter">ECO<span className="text-emerald-500">SMART</span></h1>
          <p className="text-gray-500 font-medium">{isSignup ? 'Create Account' : 'Admin Login'}</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {isSignup && (
            <>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Full Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-bold"
                  placeholder="Arjun Sharma"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Email Address</label>
                <input 
                  type="email" 
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-bold"
                  placeholder="arjun@example.in"
                  required
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Phone Number</label>
                <input 
                  type="tel" 
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-bold"
                  placeholder="+91 98765 43210"
                  required
                />
              </div>
            </>
          )}
          
          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Login ID</label>
            <div className="relative">
              <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                value={formData.login_id}
                onChange={(e) => setFormData({...formData, login_id: e.target.value})}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-12 pr-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-bold"
                placeholder="admin01"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1 uppercase">Password</label>
            <div className="relative">
              <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="password" 
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                className="w-full bg-gray-50 border border-gray-200 rounded-xl pl-12 pr-4 py-3 focus:ring-2 focus:ring-emerald-500 outline-none transition-all font-bold"
                placeholder="••••••••"
                required
              />
            </div>
          </div>

          {error && <p className="text-rose-500 text-xs font-bold text-center">{error}</p>}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-gray-900 text-white py-4 rounded-2xl font-black text-lg shadow-xl hover:bg-black transition-all active:scale-95 disabled:opacity-50"
          >
            {loading ? 'PROCESSING...' : (isSignup ? 'CREATE ACCOUNT' : 'SIGN IN')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <button 
            onClick={() => setIsSignup(!isSignup)}
            className="text-emerald-600 text-sm font-bold hover:underline"
          >
            {isSignup ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
          </button>
        </div>

        <p className="mt-8 text-center text-[10px] text-gray-400 font-medium uppercase tracking-widest">
          Secure DBMS Access • {new Date().getFullYear()} EcoSmart
        </p>
      </motion.div>
    </div>
  );
};

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [data, setData] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);

  const [showAddModal, setShowAddModal] = useState(false);
  const [showReportModal, setShowReportModal] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState<{show: boolean, id: number | null}>({show: false, id: null});
  const [paymentStep, setPaymentStep] = useState<'method' | 'details' | 'processing' | 'success'>('method');
  const [searchQuery, setSearchQuery] = useState('');
  const [formData, setFormData] = useState<any>({});

  const [statusMessage, setStatusMessage] = useState<{ text: string, type: 'success' | 'error' } | null>(null);

  const [wasteTypes, setWasteTypes] = useState<any[]>([]);
  const [allHouseholds, setAllHouseholds] = useState<any[]>([]);
  const [allCitizens, setAllCitizens] = useState<any[]>([]);

  useEffect(() => {
    if (user) {
      fetchStats();
      fetchTabData();
      fetchWasteTypes();
      fetchAllLookups();
    }
  }, [user, activeTab]);

  const fetchAllLookups = async () => {
    try {
      const [hRes, cRes] = await Promise.all([
        fetch('/api/households'),
        fetch('/api/citizens')
      ]);
      const hData = await hRes.json();
      const cData = await cRes.json();
      setAllHouseholds(hData);
      setAllCitizens(cData);
    } catch (err) {
      console.error('Failed to fetch lookups');
    }
  };

  const fetchWasteTypes = async () => {
    try {
      const res = await fetch('/api/waste-types');
      const data = await res.json();
      setWasteTypes(data);
    } catch (err) {
      console.error('Failed to fetch waste types');
    }
  };

  const fetchStats = async () => {
    try {
      const res = await fetch('/api/stats');
      const data = await res.json();
      setStats(data);
    } catch (err) {
      console.error('Failed to fetch stats');
    }
  };

  const fetchTabData = async () => {
    if (activeTab === 'dashboard' || activeTab === 'info') return;
    setLoading(true);
    try {
      let endpoint = `/api/${activeTab}`;
      if (activeTab === 'waste') endpoint = '/api/bins';
      if (activeTab === 'logistics') endpoint = '/api/logistics';
      
      const res = await fetch(endpoint);
      if (!res.ok) throw new Error(`HTTP error! status: ${res.status}`);
      const result = await res.json();
      
      if (activeTab === 'logistics') {
        setData(result.vehicles || []);
      } else {
        setData(Array.isArray(result) ? result : result.citizens || []);
      }
    } catch (err) {
      console.error('Failed to fetch tab data:', err);
    }
    setLoading(false);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this record?')) return;
    try {
      let endpoint = `/api/${activeTab}/${id}`;
      if (activeTab === 'waste') endpoint = `/api/bins/${id}`;
      
      const res = await fetch(endpoint, { method: 'DELETE' });
      if (res.ok) {
        fetchTabData();
        fetchStats();
      }
    } catch (err) {
      console.error('Delete failed');
    }
  };

  const filteredData = data.filter(item => {
    if (!searchQuery) return true;
    const q = searchQuery.toLowerCase();
    return Object.values(item).some(val => 
      val && val.toString().toLowerCase().includes(q)
    );
  });

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      let endpoint = `/api/${activeTab}`;
      if (activeTab === 'waste') endpoint = '/api/bins';
      
      console.log('Adding record to:', endpoint, formData);
      
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData),
      });
      
      const result = await res.json();
      console.log('Add result:', result);

      if (res.ok) {
        setStatusMessage({ text: 'Record added successfully!', type: 'success' });
        setTimeout(() => {
          setShowAddModal(false);
          setFormData({});
          setStatusMessage(null);
          fetchTabData();
          fetchStats();
        }, 1500);
      } else {
        setStatusMessage({ text: result.error || 'Failed to add record', type: 'error' });
      }
    } catch (err) {
      console.error('Add failed:', err);
      setStatusMessage({ text: 'Network error while adding record', type: 'error' });
    }
    setLoading(false);
  };

  const handlePayFine = (id: number) => {
    setShowPaymentModal({ show: true, id });
    setPaymentStep('method');
  };

  const confirmPayment = async () => {
    if (!showPaymentModal.id) return;
    setPaymentStep('processing');
    
    // Simulate processing delay for realism
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      const res = await fetch(`/api/finance/pay/${showPaymentModal.id}`, { method: 'POST' });
      if (res.ok) {
        setPaymentStep('success');
        setTimeout(() => {
          setShowPaymentModal({ show: false, id: null });
          fetchTabData();
          fetchStats();
        }, 1500);
      }
    } catch (err) {
      console.error('Payment failed');
      setPaymentStep('method');
    }
  };

  const tabs = [
    { id: 'dashboard', label: 'Dashboard', icon: BarChart3, color: 'bg-indigo-500' },
    { id: 'citizens', label: 'Citizens', icon: Users, color: 'bg-emerald-500' },
    { id: 'households', label: 'Households', icon: Home, color: 'bg-orange-500' },
    { id: 'waste', label: 'Waste Bins', icon: Recycle, color: 'bg-rose-500' },
    { id: 'logistics', label: 'Logistics', icon: Truck, color: 'bg-blue-500' },
    { id: 'finance', label: 'Finance', icon: CreditCard, color: 'bg-amber-500' },
    { id: 'complaints', label: 'Complaints', icon: AlertCircle, color: 'bg-purple-500' },
    { id: 'info', label: 'Info Center', icon: ShieldCheck, color: 'bg-slate-700' },
  ];

  if (!user) return <Login onLogin={setUser} />;

  return (
    <div className="min-h-screen bg-[#F8FAFC] flex font-sans text-gray-900">
      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: sidebarOpen ? 280 : 100 }}
        className="bg-[#1E293B] h-screen sticky top-0 flex flex-col transition-all duration-300 z-50 shadow-2xl"
      >
        <div className="p-6 flex items-center space-x-3 overflow-hidden">
          <div className="bg-emerald-500 p-2 rounded-xl shadow-lg shadow-emerald-500/20 flex-shrink-0">
            <Recycle className="text-white" size={24} />
          </div>
          {sidebarOpen && (
            <motion.h1 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-white font-black text-xl tracking-tighter whitespace-nowrap"
            >
              ECO<span className="text-emerald-400">SMART</span>
            </motion.h1>
          )}
        </div>

        <nav className="flex-1 px-4 space-y-1 mt-4">
          {tabs.map((tab) => (
            <SidebarItem
              key={tab.id}
              icon={tab.icon}
              label={tab.label}
              active={activeTab === tab.id}
              onClick={() => setActiveTab(tab.id)}
              color={tab.color}
              collapsed={!sidebarOpen}
            />
          ))}
        </nav>

        <div className="p-4 border-t border-white/5 space-y-2">
          <div className="flex items-center space-x-3 px-4 py-3 text-white/70">
            <div className="bg-white/10 p-2 rounded-lg">
              <User size={18} />
            </div>
            {sidebarOpen && (
              <div className="overflow-hidden">
                <p className="text-xs font-bold text-white truncate">{user.name}</p>
                <p className="text-[10px] text-white/40 truncate">{user.role}</p>
              </div>
            )}
          </div>
          <button 
            onClick={() => setUser(null)}
            className="w-full flex items-center space-x-3 px-4 py-3 text-rose-400 hover:bg-rose-500/10 rounded-xl transition-colors"
          >
            <LogOut size={18} />
            {sidebarOpen && <span className="text-sm font-bold">Logout</span>}
          </button>
          <button 
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="w-full flex items-center justify-center p-3 text-white/50 hover:text-white hover:bg-white/5 rounded-xl transition-colors"
          >
            {sidebarOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-auto">
        <header className="flex items-center justify-between mb-10">
          <div>
            <h2 className="text-3xl font-black text-gray-900 tracking-tight capitalize">
              {activeTab.replace('-', ' ')}
            </h2>
            <p className="text-gray-500 font-medium">System Management Console</p>
          </div>
          <div className="flex items-center space-x-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={18} />
              <input 
                type="text" 
                placeholder="Search records..." 
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white border border-gray-200 rounded-2xl pl-10 pr-4 py-2 text-sm focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none w-64 transition-all"
              />
            </div>
            {['citizens', 'households', 'waste', 'complaints'].includes(activeTab) && (
              <button 
                onClick={() => {
                  setFormData({});
                  setStatusMessage(null);
                  setShowAddModal(true);
                }}
                className="bg-emerald-500 text-white p-2 rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-105 transition-transform"
              >
                <Plus size={24} />
              </button>
            )}
          </div>
        </header>

        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' ? (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <Card title="Total Citizens" value={stats?.citizens?.count || 0} icon={Users} color="bg-indigo-500" delay={0.1} />
                <Card title="Active Bins" value={stats?.bins?.count || 0} icon={Recycle} color="bg-emerald-500" delay={0.2} />
                <Card title="Open Complaints" value={stats?.complaints?.count || 0} icon={AlertCircle} color="bg-rose-500" delay={0.3} />
                <Card title="Waste Collected (kg)" value={stats?.totalWaste?.total || 0} icon={BarChart3} color="bg-amber-500" delay={0.4} />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8">
                  <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-100">
                    <div className="flex items-center justify-between mb-8">
                      <h3 className="text-xl font-black">System Overview</h3>
                      <div className="flex space-x-2">
                        <button className="p-2 bg-gray-50 rounded-xl text-gray-400"><Filter size={18} /></button>
                        <button className="p-2 bg-gray-50 rounded-xl text-gray-400"><Clock size={18} /></button>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-6 mb-8">
                      <div className="bg-indigo-50 p-6 rounded-3xl border border-indigo-100">
                        <p className="text-indigo-600 text-xs font-black uppercase tracking-widest mb-2">Household Coverage</p>
                        <h4 className="text-3xl font-black text-indigo-900">94.2%</h4>
                        <div className="w-full h-2 bg-indigo-200 rounded-full mt-4 overflow-hidden">
                          <div className="w-[94%] h-full bg-indigo-600" />
                        </div>
                      </div>
                      <div className="bg-emerald-50 p-6 rounded-3xl border border-emerald-100">
                        <p className="text-emerald-600 text-xs font-black uppercase tracking-widest mb-2">Recycling Rate</p>
                        <h4 className="text-3xl font-black text-emerald-900">68.5%</h4>
                        <div className="w-full h-2 bg-emerald-200 rounded-full mt-4 overflow-hidden">
                          <div className="w-[68%] h-full bg-emerald-600" />
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h4 className="font-bold text-gray-400 text-xs uppercase tracking-widest">Recent Activity</h4>
                      {[1, 2, 3].map(i => (
                        <div key={i} className="flex items-center justify-between p-4 hover:bg-gray-50 rounded-2xl transition-colors">
                          <div className="flex items-center space-x-4">
                            <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center text-gray-500">
                              <Truck size={20} />
                            </div>
                            <div>
                              <p className="font-bold text-sm">Collection Route #{100+i} Completed</p>
                              <p className="text-xs text-gray-400">North Zone • 2 hours ago</p>
                            </div>
                          </div>
                          <CheckCircle2 size={20} className="text-emerald-500" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="space-y-8">
                  <div className="bg-gray-900 rounded-[40px] p-8 text-white relative overflow-hidden">
                    <div className="relative z-10">
                      <h3 className="text-xl font-black mb-4">Quick Actions</h3>
                      <div className="space-y-3">
                        <button 
                          onClick={() => {
                            setActiveTab('logistics');
                            setShowAddModal(true);
                          }}
                          className="w-full bg-white/10 hover:bg-white/20 p-4 rounded-2xl flex items-center justify-between transition-all"
                        >
                          <span className="font-bold text-sm">Deploy Vehicle</span>
                          <ChevronRight size={18} />
                        </button>
                        <button 
                          onClick={() => {
                            setStatusMessage({ text: 'Pickup scheduled for tomorrow morning!', type: 'success' });
                            setTimeout(() => setStatusMessage(null), 3000);
                          }}
                          className="w-full bg-white/10 hover:bg-white/20 p-4 rounded-2xl flex items-center justify-between transition-all"
                        >
                          <span className="font-bold text-sm">Schedule Pickup</span>
                          <ChevronRight size={18} />
                        </button>
                        <button 
                          onClick={() => {
                            setShowReportModal(true);
                          }}
                          className="w-full bg-emerald-500 text-gray-900 p-4 rounded-2xl flex items-center justify-between transition-all font-black"
                        >
                          <span>Generate Report</span>
                          <BarChart3 size={18} />
                        </button>
                      </div>
                    </div>
                    <DbIcon className="absolute -right-10 -bottom-10 text-white/5 w-48 h-48" />
                  </div>

                  <div className="bg-white rounded-[40px] p-8 shadow-sm border border-gray-100">
                    <h3 className="font-black mb-6">Waste Distribution</h3>
                    <div className="space-y-6">
                      {[
                        { label: 'Organic', color: 'bg-emerald-500', val: 45 },
                        { label: 'Plastic', color: 'bg-blue-500', val: 30 },
                        { label: 'E-Waste', color: 'bg-amber-500', val: 15 },
                        { label: 'Glass', color: 'bg-rose-500', val: 10 },
                      ].map(item => (
                        <div key={item.label}>
                          <div className="flex justify-between text-xs font-bold mb-2">
                            <span>{item.label}</span>
                            <span className="text-gray-400">{item.val}%</span>
                          </div>
                          <div className="w-full h-1.5 bg-gray-100 rounded-full overflow-hidden">
                            <div className={`h-full ${item.color}`} style={{ width: `${item.val}%` }} />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : (
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="space-y-6"
            >
              {activeTab === 'citizens' && (
                <Table 
                  headers={['ID', 'Name', 'Email', 'Phone', 'Address', 'Household']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-gray-400">#C-{item.id}</td>
                      <td className="px-6 py-4 font-bold">{item.name}</td>
                      <td className="px-6 py-4 text-gray-500">{item.email}</td>
                      <td className="px-6 py-4 text-gray-500">{item.phone}</td>
                      <td className="px-6 py-4 text-gray-500">{item.address}</td>
                      <td className="px-6 py-4">
                        <span className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold">
                          {item.household_address || (item.household_id ? `ID: ${item.household_id}` : 'Unassigned')}
                        </span>
                      </td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'households' && (
                <Table 
                  headers={['ID', 'Address', 'Area', 'Residents']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-gray-400">#H-{item.id}</td>
                      <td className="px-6 py-4 font-bold">{item.address}</td>
                      <td className="px-6 py-4 text-gray-500">{item.area}</td>
                      <td className="px-6 py-4">
                        <div className="flex items-center space-x-2">
                          <Users size={14} className="text-gray-400" />
                          <span className="font-bold">{item.residents_count}</span>
                        </div>
                      </td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'waste' && (
                <Table 
                  headers={['Bin ID', 'Household', 'Type', 'Size', 'Status']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-gray-400">#BIN-{item.id}</td>
                      <td className="px-6 py-4 font-bold">{item.household_address || (item.household_id ? `ID: ${item.household_id}` : 'Unassigned')}</td>
                      <td className="px-6 py-4">
                        <span className="bg-gray-100 px-3 py-1 rounded-full text-xs font-bold">{item.type_name || 'General'}</span>
                      </td>
                      <td className="px-6 py-4 text-gray-500">{item.size}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          item.status === 'Full' ? 'bg-rose-50 text-rose-600' : 
                          item.status === 'Empty' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'logistics' && (
                <Table 
                  headers={['Vehicle #', 'Driver Name', 'Driver Phone', 'License', 'Capacity', 'Status']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-black">{item.vehicle_number}</td>
                      <td className="px-6 py-4 font-bold text-gray-600">{item.driver_name || 'Unassigned'}</td>
                      <td className="px-6 py-4 text-gray-500">{item.driver_phone || 'N/A'}</td>
                      <td className="px-6 py-4 font-mono text-xs">{item.license_number || 'N/A'}</td>
                      <td className="px-6 py-4 text-gray-500">{item.capacity} kg</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          item.status === 'Active' ? 'bg-emerald-50 text-emerald-600' : 'bg-gray-100 text-gray-400'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'finance' && (
                <Table 
                  headers={['ID', 'Household', 'Amount', 'Reason', 'Status', 'Actions']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-mono text-xs text-gray-400">#TX-{item.id}</td>
                      <td className="px-6 py-4 font-bold">{item.household_address}</td>
                      <td className="px-6 py-4 font-black text-emerald-600">₹{item.amount}</td>
                      <td className="px-6 py-4 text-gray-500 text-sm">{item.reason}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          item.status === 'Paid' ? 'bg-emerald-50 text-emerald-600' : 'bg-amber-50 text-amber-600'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {item.status === 'Pending' && (
                          <button 
                            onClick={() => handlePayFine(item.id)}
                            className="bg-emerald-500 text-white px-3 py-1 rounded-lg text-xs font-bold hover:bg-emerald-600 transition-colors"
                          >
                            Pay Fine
                          </button>
                        )}
                      </td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'complaints' && (
                <Table 
                  headers={['Type', 'Citizen', 'Description', 'Status', 'Date']}
                  data={filteredData}
                  renderRow={(item: any) => (
                    <tr key={item.id} className="hover:bg-gray-50/50 transition-colors">
                      <td className="px-6 py-4 font-bold text-rose-600">{item.type || 'General'}</td>
                      <td className="px-6 py-4 font-bold">{item.citizen_name || (item.citizen_id ? `ID: ${item.citizen_id}` : 'Anonymous')}</td>
                      <td className="px-6 py-4 text-gray-500 text-sm max-w-xs truncate">{item.description}</td>
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                          item.status === 'Open' ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                        }`}>
                          {item.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-gray-400 text-xs">{item.date_filed}</td>
                    </tr>
                  )}
                />
              )}

              {activeTab === 'info' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div className="bg-white p-8 rounded-[40px] shadow-sm border border-gray-100">
                    <h3 className="text-xl font-black mb-6 flex items-center space-x-2">
                      <AlertCircle className="text-emerald-500" />
                      <span>Waste Management Facts</span>
                    </h3>
                    <div className="space-y-4">
                      <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                        <p className="font-bold text-emerald-900">Did you know?</p>
                        <p className="text-sm text-emerald-700">Recycling one aluminum can saves enough energy to run a TV for three hours.</p>
                      </div>
                      <div className="p-4 bg-blue-50 rounded-2xl border border-blue-100">
                        <p className="font-bold text-blue-900">Plastic Pollution</p>
                        <p className="text-sm text-blue-700">Over 8 million tons of plastic enter our oceans every year.</p>
                      </div>
                      <div className="p-4 bg-amber-50 rounded-2xl border border-amber-100">
                        <p className="font-bold text-amber-900">Composting</p>
                        <p className="text-sm text-amber-700">Organic waste in landfills generates methane, a potent greenhouse gas. Composting reduces this significantly.</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gray-900 p-8 rounded-[40px] shadow-sm text-white">
                    <h3 className="text-xl font-black mb-6 flex items-center space-x-2">
                      <Users className="text-emerald-400" />
                      <span>Important Contacts</span>
                    </h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                        <div>
                          <p className="font-bold">Emergency Waste Spills</p>
                          <p className="text-xs text-white/50">24/7 Hotline</p>
                        </div>
                        <p className="text-emerald-400 font-black">1-800-ECO-HELP</p>
                      </div>
                      <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                        <div>
                          <p className="font-bold">Recycling Inquiries</p>
                          <p className="text-xs text-white/50">Mon-Fri 9AM-5PM</p>
                        </div>
                        <p className="text-emerald-400 font-black">555-RECYCLE</p>
                      </div>
                      <div className="flex justify-between items-center p-4 bg-white/5 rounded-2xl">
                        <div>
                          <p className="font-bold">General Complaints</p>
                          <p className="text-xs text-white/50">Citizen Portal</p>
                        </div>
                        <p className="text-emerald-400 font-black">support@ecosmart.com</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      {/* Report Modal */}
      <AnimatePresence>
        {showReportModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowReportModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white rounded-[40px] w-full max-w-2xl overflow-hidden shadow-2xl"
            >
              <div className="p-8 border-b border-gray-100 flex justify-between items-center bg-gray-900 text-white">
                <div>
                  <h2 className="text-2xl font-black tracking-tighter">SYSTEM REPORT</h2>
                  <p className="text-xs text-white/50 uppercase tracking-widest font-bold">Generated on {new Date().toLocaleDateString()}</p>
                </div>
                <button onClick={() => setShowReportModal(false)} className="text-white/50 hover:text-white"><X size={24} /></button>
              </div>
              
              <div className="p-8 space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-4 bg-gray-50 rounded-2xl">
                    <p className="text-xs text-gray-400 font-bold uppercase mb-1">Citizen Engagement</p>
                    <p className="text-2xl font-black">{stats?.citizens?.count || 0}</p>
                  </div>
                  <div className="p-4 bg-gray-50 rounded-2xl">
                    <p className="text-xs text-gray-400 font-bold uppercase mb-1">Active Infrastructure</p>
                    <p className="text-2xl font-black">{stats?.bins?.count || 0} Bins</p>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-black text-sm uppercase tracking-wider">Efficiency Metrics</h4>
                  <div className="space-y-3">
                    {[
                      { label: 'Collection Rate', val: '94%' },
                      { label: 'Citizen Satisfaction', val: '88%' },
                      { label: 'Recycling Purity', val: '76%' }
                    ].map(m => (
                      <div key={m.label} className="flex justify-between items-center p-3 bg-gray-50 rounded-xl">
                        <span className="text-sm font-bold text-gray-600">{m.label}</span>
                        <span className="font-black text-emerald-600">{m.val}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="p-6 bg-emerald-50 rounded-3xl border border-emerald-100">
                  <div className="flex items-center space-x-3 mb-2">
                    <CheckCircle2 className="text-emerald-500" size={20} />
                    <p className="font-black text-emerald-900">AI Recommendation</p>
                  </div>
                  <p className="text-sm text-emerald-700 leading-relaxed">
                    Based on current trends, we recommend deploying 2 additional vehicles to the North Zone during peak hours (08:00 - 10:00) to optimize collection efficiency.
                  </p>
                </div>

                <button 
                  onClick={() => {
                    setShowReportModal(false);
                    setStatusMessage({ text: 'Report exported as PDF successfully!', type: 'success' });
                    setTimeout(() => setStatusMessage(null), 3000);
                  }}
                  className="w-full bg-gray-900 text-white p-4 rounded-2xl font-black hover:bg-gray-800 transition-all flex items-center justify-center space-x-2"
                >
                  <CreditCard size={18} />
                  <span>EXPORT FULL DATASET</span>
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Payment Modal */}
      <AnimatePresence>
        {showPaymentModal.show && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
              onClick={() => setShowPaymentModal({ show: false, id: null })}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ scale: 0.9, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.9, opacity: 0, y: 20 }}
              className="relative bg-white w-full max-w-md rounded-[2.5rem] shadow-2xl overflow-hidden z-10"
            >
              <div className="p-8 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-2xl font-black">Secure Payment</h3>
                <button onClick={() => setShowPaymentModal({ show: false, id: null })} className="text-gray-400 hover:text-gray-600"><X size={24} /></button>
              </div>
              
              <div className="p-8">
                {paymentStep === 'method' && (
                  <div className="space-y-4">
                    <p className="text-gray-500 mb-6">Select your preferred payment method to settle the fine.</p>
                    <button 
                      onClick={() => setPaymentStep('details')}
                      className="w-full p-6 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-between hover:border-emerald-500 transition-all group"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="p-3 bg-white rounded-xl shadow-sm group-hover:bg-emerald-50 transition-colors">
                          <CreditCard className="text-emerald-500" />
                        </div>
                        <span className="font-bold text-lg">Credit / Debit Card</span>
                      </div>
                      <ChevronRight className="text-gray-300" />
                    </button>
                    <button 
                      onClick={() => setPaymentStep('details')}
                      className="w-full p-6 bg-gray-50 border border-gray-100 rounded-2xl flex items-center justify-between hover:border-emerald-500 transition-all group"
                    >
                      <div className="flex items-center space-x-4">
                        <div className="p-3 bg-white rounded-xl shadow-sm group-hover:bg-emerald-50 transition-colors">
                          <ShieldCheck className="text-emerald-500" />
                        </div>
                        <span className="font-bold text-lg">Net Banking</span>
                      </div>
                      <ChevronRight className="text-gray-300" />
                    </button>
                  </div>
                )}

                {paymentStep === 'details' && (
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Card Number</label>
                      <input type="text" placeholder="xxxx xxxx xxxx xxxx" className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl font-mono" />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">Expiry</label>
                        <input type="text" placeholder="MM/YY" className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl font-mono" />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs font-black text-gray-400 uppercase tracking-widest ml-1">CVV</label>
                        <input type="password" placeholder="***" className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl font-mono" />
                      </div>
                    </div>
                    <button 
                      onClick={confirmPayment}
                      className="w-full bg-emerald-500 text-white py-4 rounded-2xl font-black text-lg shadow-xl hover:bg-emerald-600 transition-all mt-6"
                    >
                      CONFIRM & PAY
                    </button>
                  </div>
                )}

                {paymentStep === 'processing' && (
                  <div className="py-12 flex flex-col items-center justify-center space-y-6">
                    <div className="w-16 h-16 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                    <p className="font-bold text-xl text-gray-700">Processing Payment...</p>
                    <p className="text-gray-400 text-sm">Please do not refresh the page</p>
                  </div>
                )}

                {paymentStep === 'success' && (
                  <div className="py-12 flex flex-col items-center justify-center space-y-6">
                    <div className="w-20 h-20 bg-emerald-100 text-emerald-500 rounded-full flex items-center justify-center">
                      <ShieldCheck size={48} />
                    </div>
                    <div className="text-center">
                      <p className="font-black text-2xl text-gray-900">Payment Successful!</p>
                      <p className="text-gray-500 mt-2">Your fine has been settled.</p>
                    </div>
                  </div>
                )}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Add Modal */}
      <AnimatePresence>
        {showAddModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-6">
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setShowAddModal(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            />
            <motion.div 
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              className="bg-white w-full max-w-lg rounded-[40px] shadow-2xl relative z-10 overflow-hidden"
            >
              <div className="p-8 border-b border-gray-100 flex items-center justify-between">
                <h3 className="text-2xl font-black capitalize">Add New {activeTab.replace('-', ' ')}</h3>
                <button onClick={() => setShowAddModal(false)} className="text-gray-400 hover:text-gray-600"><X size={24} /></button>
              </div>
              
              <div className="px-8 pt-6">
                {statusMessage && (
                  <div className={`p-4 rounded-2xl text-sm font-bold ${
                    statusMessage.type === 'success' ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'
                  }`}>
                    {statusMessage.text}
                  </div>
                )}
              </div>

              <form onSubmit={handleAdd} className="p-8 space-y-4">
                {activeTab === 'citizens' && (
                  <>
                    <input type="text" placeholder="Full Name" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.name || ''} onChange={e => setFormData({...formData, name: e.target.value})} />
                    <input type="email" placeholder="Email" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.email || ''} onChange={e => setFormData({...formData, email: e.target.value})} />
                    <input type="tel" placeholder="Phone" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.phone || ''} onChange={e => setFormData({...formData, phone: e.target.value})} />
                    <input type="text" placeholder="Address" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.address || ''} onChange={e => setFormData({...formData, address: e.target.value})} />
                    <div className="relative">
                      <input 
                        list="households-list"
                        placeholder="Select or enter Household ID" 
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" 
                        value={formData.household_id || ''} 
                        onChange={e => setFormData({...formData, household_id: e.target.value})} 
                      />
                      <datalist id="households-list">
                        {allHouseholds.map(h => (
                          <option key={h.id} value={h.id}>{h.address}</option>
                        ))}
                      </datalist>
                      <p className="text-[10px] text-gray-400 mt-1 ml-2">Tip: Select from list or type the ID directly</p>
                    </div>
                  </>
                )}
                {activeTab === 'households' && (
                  <>
                    <input type="text" placeholder="Address" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.address || ''} onChange={e => setFormData({...formData, address: e.target.value})} />
                    <input type="text" placeholder="Area" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.area || ''} onChange={e => setFormData({...formData, area: e.target.value})} />
                    <input type="number" placeholder="Residents Count" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.residents_count || ''} onChange={e => setFormData({...formData, residents_count: e.target.value})} />
                  </>
                )}
                {activeTab === 'waste' && (
                  <>
                    <select required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.size || ''} onChange={e => setFormData({...formData, size: e.target.value})}>
                      <option value="">Select Size</option>
                      <option value="Small">Small</option>
                      <option value="Medium">Medium</option>
                      <option value="Large">Large</option>
                    </select>
                    <select required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.status || ''} onChange={e => setFormData({...formData, status: e.target.value})}>
                      <option value="">Select Status</option>
                      <option value="Empty">Empty</option>
                      <option value="Half-Full">Half-Full</option>
                      <option value="Full">Full</option>
                    </select>
                    <div className="relative">
                      <input 
                        list="households-list-waste"
                        placeholder="Select or enter Household ID" 
                        className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" 
                        value={formData.household_id || ''} 
                        onChange={e => setFormData({...formData, household_id: e.target.value})} 
                      />
                      <datalist id="households-list-waste">
                        {allHouseholds.map(h => (
                          <option key={h.id} value={h.id}>{h.address}</option>
                        ))}
                      </datalist>
                      <p className="text-[10px] text-gray-400 mt-1 ml-2">Tip: Select from list or type the ID directly</p>
                    </div>
                    <select required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.waste_type_id || ''} onChange={e => setFormData({...formData, waste_type_id: e.target.value})}>
                      <option value="">Select Waste Type</option>
                      {wasteTypes.map(type => (
                        <option key={type.id} value={type.id}>{type.name}</option>
                      ))}
                    </select>
                  </>
                )}
                {activeTab === 'complaints' && (
                  <>
                    <select required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.citizen_id || ''} onChange={e => setFormData({...formData, citizen_id: e.target.value})}>
                      <option value="">Select Citizen</option>
                      {allCitizens.map(c => (
                        <option key={c.id} value={c.id}>{c.name} (ID: {c.id})</option>
                      ))}
                    </select>
                    <input type="text" placeholder="Complaint Type (e.g. Missed Collection)" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.type || ''} onChange={e => setFormData({...formData, type: e.target.value})} />
                    <textarea placeholder="Description / Location" required className="w-full p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.description || ''} onChange={e => setFormData({...formData, description: e.target.value})} />
                    <div className="grid grid-cols-2 gap-4">
                      <select required className="p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.urgency || ''} onChange={e => setFormData({...formData, urgency: e.target.value})}>
                        <option value="">Urgency</option>
                        <option value="Low">Low</option>
                        <option value="Medium">Medium</option>
                        <option value="High">High</option>
                      </select>
                      <input type="date" className="p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.date_filed || ''} onChange={e => setFormData({...formData, date_filed: e.target.value})} />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <input type="time" className="p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.time_filed || ''} onChange={e => setFormData({...formData, time_filed: e.target.value})} />
                      <input type="text" placeholder="Proof (Link/Ref)" className="p-4 bg-gray-50 border border-gray-100 rounded-2xl" value={formData.proof || ''} onChange={e => setFormData({...formData, proof: e.target.value})} />
                    </div>
                  </>
                )}
                <button type="submit" className="w-full bg-emerald-500 text-white py-4 rounded-2xl font-black text-lg shadow-xl hover:bg-emerald-600 transition-all">
                  SAVE RECORD
                </button>
              </form>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}
