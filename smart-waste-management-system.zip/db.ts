import Database from 'better-sqlite3';

const db = new Database('waste_management.db');
db.pragma('foreign_keys = ON');

// Initialize tables based on ERD
export function initDb() {
  db.exec(`
    -- Waste Types
    CREATE TABLE IF NOT EXISTS waste_types (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      description TEXT
    );

    -- Households
    CREATE TABLE IF NOT EXISTS households (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      address TEXT NOT NULL,
      area TEXT NOT NULL,
      residents_count INTEGER DEFAULT 1
    );

    -- Citizens
    CREATE TABLE IF NOT EXISTS citizens (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      phone TEXT,
      email TEXT,
      address TEXT,
      household_id INTEGER,
      FOREIGN KEY (household_id) REFERENCES households(id)
    );

    -- Waste Bins
    CREATE TABLE IF NOT EXISTS waste_bins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      size TEXT NOT NULL,
      status TEXT DEFAULT 'Empty',
      installation_date DATE,
      household_id INTEGER,
      waste_type_id INTEGER,
      FOREIGN KEY (household_id) REFERENCES households(id),
      FOREIGN KEY (waste_type_id) REFERENCES waste_types(id)
    );

    -- Drivers
    CREATE TABLE IF NOT EXISTS drivers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      license_number TEXT UNIQUE,
      phone TEXT
    );

    -- Collection Vehicles
    CREATE TABLE IF NOT EXISTS collection_vehicles (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      vehicle_number TEXT UNIQUE NOT NULL,
      capacity REAL,
      status TEXT DEFAULT 'Active',
      driver_id INTEGER,
      FOREIGN KEY (driver_id) REFERENCES drivers(id)
    );

    -- Collection Schedules
    CREATE TABLE IF NOT EXISTS collection_schedules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      collection_day TEXT NOT NULL,
      time_slot TEXT NOT NULL,
      area TEXT NOT NULL,
      vehicle_id INTEGER,
      FOREIGN KEY (vehicle_id) REFERENCES collection_vehicles(id)
    );

    -- Transfer Stations
    CREATE TABLE IF NOT EXISTS transfer_stations (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      location TEXT NOT NULL,
      capacity REAL
    );

    -- Collection Records
    CREATE TABLE IF NOT EXISTS collection_records (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      collection_date DATE DEFAULT CURRENT_DATE,
      collected_weight REAL,
      bin_id INTEGER,
      vehicle_id INTEGER,
      station_id INTEGER,
      FOREIGN KEY (bin_id) REFERENCES waste_bins(id),
      FOREIGN KEY (vehicle_id) REFERENCES collection_vehicles(id),
      FOREIGN KEY (station_id) REFERENCES transfer_stations(id)
    );

    -- Recycling Centers
    CREATE TABLE IF NOT EXISTS recycling_centers (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      location TEXT NOT NULL,
      contact_number TEXT
    );

    -- Station to Center Supply
    CREATE TABLE IF NOT EXISTS station_supplies (
      station_id INTEGER,
      center_id INTEGER,
      PRIMARY KEY (station_id, center_id),
      FOREIGN KEY (station_id) REFERENCES transfer_stations(id),
      FOREIGN KEY (center_id) REFERENCES recycling_centers(id)
    );

    -- Processing Units
    CREATE TABLE IF NOT EXISTS processing_units (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      unit_type TEXT NOT NULL,
      capacity REAL,
      center_id INTEGER,
      FOREIGN KEY (center_id) REFERENCES recycling_centers(id)
    );

    -- Payments and Fines
    CREATE TABLE IF NOT EXISTS payments_fines (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      amount REAL NOT NULL,
      reason TEXT,
      payment_date DATE DEFAULT CURRENT_DATE,
      status TEXT DEFAULT 'Pending',
      household_id INTEGER,
      FOREIGN KEY (household_id) REFERENCES households(id)
    );

    -- Complaints
    CREATE TABLE IF NOT EXISTS complaints (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      type TEXT NOT NULL,
      description TEXT,
      status TEXT DEFAULT 'Open',
      date_filed DATE DEFAULT CURRENT_DATE,
      citizen_id INTEGER,
      admin_id INTEGER,
      FOREIGN KEY (citizen_id) REFERENCES citizens(id),
      FOREIGN KEY (admin_id) REFERENCES admins(id)
    );

    -- Admins (Users)
    CREATE TABLE IF NOT EXISTS admins (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      role TEXT,
      login_id TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      email TEXT,
      phone TEXT
    );

    -- Migration: Add columns if they don't exist (for existing databases)
    PRAGMA table_info(admins);
  `);

  // Simple migration check
  const columns = db.prepare("PRAGMA table_info(admins)").all() as any[];
  const columnNames = columns.map(c => c.name);
  if (!columnNames.includes('password')) {
    db.prepare("ALTER TABLE admins ADD COLUMN password TEXT DEFAULT 'password123'").run();
  }
  if (!columnNames.includes('email')) {
    db.prepare("ALTER TABLE admins ADD COLUMN email TEXT").run();
  }
  if (!columnNames.includes('phone')) {
    db.prepare("ALTER TABLE admins ADD COLUMN phone TEXT").run();
  }

  // Seed some initial data if empty
  const adminsCount = db.prepare('SELECT count(*) as count FROM admins').get() as { count: number };
  if (adminsCount.count === 0) {
    const insertType = db.prepare('INSERT INTO waste_types (name, description) VALUES (?, ?)');
    insertType.run('Organic', 'Biodegradable kitchen and garden waste');
    insertType.run('Plastic', 'Recyclable plastic containers and packaging');
    insertType.run('E-Waste', 'Electronic components and devices');
    insertType.run('Glass', 'Glass bottles and jars');
    
    const insertAdmin = db.prepare('INSERT INTO admins (name, role, login_id, password, email, phone) VALUES (?, ?, ?, ?, ?, ?)');
    insertAdmin.run('Arjun Sharma', 'Senior Manager', 'admin01', 'password123', 'arjun@ecosmart.in', '+91 98765 43210');

    const insertStation = db.prepare('INSERT INTO transfer_stations (location, capacity) VALUES (?, ?)');
    insertStation.run('Mumbai North Hub', 5000);
    insertStation.run('Bangalore South Station', 3500);

    const insertCenter = db.prepare('INSERT INTO recycling_centers (name, location, contact_number) VALUES (?, ?, ?)');
    insertCenter.run('Swachh Bharat Recycling', 'Industrial Area, Pune', '020-254321');
    insertCenter.run('Digital India E-Waste', 'Electronic City, Bangalore', '080-456789');

    const insertHousehold = db.prepare('INSERT INTO households (address, area, residents_count) VALUES (?, ?, ?)');
    insertHousehold.run('Flat 402, Shanti Niwas', 'Andheri West, Mumbai', 4);
    insertHousehold.run('House 12, Green Park', 'Indiranagar, Bangalore', 2);
    insertHousehold.run('Villa 7, Royal Palms', 'Banjara Hills, Hyderabad', 3);
    insertHousehold.run('Apt 101, Sky High', 'Salt Lake, Kolkata', 5);
    insertHousehold.run('Plot 45, Heritage Colony', 'Civil Lines, Delhi', 1);

    const insertCitizen = db.prepare('INSERT INTO citizens (name, phone, email, address, household_id) VALUES (?, ?, ?, ?, ?)');
    insertCitizen.run('Aarav Patel', '+91 91234 56789', 'aarav@example.in', 'Andheri West, Mumbai', 1);
    insertCitizen.run('Ishani Gupta', '+91 92345 67890', 'ishani@example.in', 'Indiranagar, Bangalore', 2);
    insertCitizen.run('Vihaan Reddy', '+91 93456 78901', 'vihaan@example.in', 'Banjara Hills, Hyderabad', 3);
    insertCitizen.run('Ananya Chatterjee', '+91 94567 89012', 'ananya@example.in', 'Salt Lake, Kolkata', 4);
    insertCitizen.run('Kabir Singh', '+91 95678 90123', 'kabir@example.in', 'Civil Lines, Delhi', 5);

    const insertBin = db.prepare('INSERT INTO waste_bins (size, status, installation_date, household_id, waste_type_id) VALUES (?, ?, ?, ?, ?)');
    insertBin.run('Large', 'Full', '2024-01-15', 1, 1);
    insertBin.run('Medium', 'Empty', '2024-02-10', 2, 2);
    insertBin.run('Small', 'Half-Full', '2024-03-05', 3, 4);
    insertBin.run('Large', 'Empty', '2024-04-01', 4, 1);
    insertBin.run('Medium', 'Full', '2024-04-15', 5, 3);

    const insertVehicle = db.prepare('INSERT INTO collection_vehicles (vehicle_number, capacity, status) VALUES (?, ?, ?)');
    insertVehicle.run('MH-01-AX-1234', 5000, 'Active');
    insertVehicle.run('KA-03-MG-5678', 3000, 'Maintenance');
    insertVehicle.run('DL-01-CZ-9012', 4500, 'Active');

    const insertRecord = db.prepare('INSERT INTO collection_records (collected_weight, bin_id, vehicle_id, station_id) VALUES (?, ?, ?, ?)');
    insertRecord.run(450.5, 1, 1, 1);
    insertRecord.run(320.2, 3, 1, 2);
    insertRecord.run(510.0, 1, 1, 1);
    insertRecord.run(280.5, 2, 1, 2);

    const insertPayment = db.prepare('INSERT INTO payments_fines (amount, reason, status, household_id) VALUES (?, ?, ?, ?)');
    insertPayment.run(500.0, 'Monthly Waste Collection Fee', 'Paid', 1);
    insertPayment.run(750.0, 'Late Disposal Fine', 'Pending', 2);
    insertPayment.run(500.0, 'Monthly Waste Collection Fee', 'Paid', 3);
    insertPayment.run(1200.0, 'Hazardous Waste Violation', 'Pending', 1);

    const insertDriver = db.prepare('INSERT INTO drivers (name, license_number, phone) VALUES (?, ?, ?)');
    insertDriver.run('Rajesh Kumar', 'IND-MH-998877', '+91 98220 11223');
    insertDriver.run('Suresh Raina', 'IND-KA-554433', '+91 98440 33445');

    db.prepare('UPDATE collection_vehicles SET driver_id = 1 WHERE id = 1').run();
    db.prepare('UPDATE collection_vehicles SET driver_id = 2 WHERE id = 2').run();

    const insertSchedule = db.prepare('INSERT INTO collection_schedules (collection_day, time_slot, area, vehicle_id) VALUES (?, ?, ?, ?)');
    insertSchedule.run('Monday', '08:00 - 12:00', 'North Zone', 1);
    insertSchedule.run('Tuesday', '09:00 - 13:00', 'South Sector', 2);
  }
}

export default db;
