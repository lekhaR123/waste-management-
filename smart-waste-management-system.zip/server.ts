import express from 'express';
import { createServer as createViteServer } from 'vite';
import db, { initDb } from './db';

async function startServer() {
  initDb();
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  
  // Stats
  app.get('/api/stats', (req, res) => {
    try {
      const stats = {
        citizens: db.prepare('SELECT count(*) as count FROM citizens').get(),
        households: db.prepare('SELECT count(*) as count FROM households').get(),
        bins: db.prepare('SELECT count(*) as count FROM waste_bins').get(),
        vehicles: db.prepare('SELECT count(*) as count FROM collection_vehicles').get(),
        complaints: db.prepare('SELECT count(*) as count FROM complaints WHERE status = \'Open\'').get(),
        totalWaste: db.prepare('SELECT sum(collected_weight) as total FROM collection_records').get(),
      };
      res.json(stats);
    } catch (error: any) {
      res.status(500).json({ error: error.message });
    }
  });

  // Citizens
  app.get('/api/citizens', (req, res) => {
    const data = db.prepare(`
      SELECT c.*, h.address as household_address 
      FROM citizens c 
      LEFT JOIN households h ON c.household_id = h.id
      ORDER BY c.id DESC
    `).all();
    res.json(data);
  });

  app.post('/api/citizens', (req, res) => {
    const { name, phone, email, address, household_id } = req.body;
    try {
      const householdId = household_id ? Number(household_id) : null;
      const stmt = db.prepare('INSERT INTO citizens (name, phone, email, address, household_id) VALUES (?, ?, ?, ?, ?)');
      const result = stmt.run(name, phone, email, address, householdId);
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  app.delete('/api/citizens/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM citizens WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  // Households
  app.get('/api/households', (req, res) => {
    const data = db.prepare('SELECT * FROM households ORDER BY id DESC').all();
    res.json(data);
  });

  app.post('/api/households', (req, res) => {
    const { address, area, residents_count } = req.body;
    try {
      const residentsCount = residents_count ? Number(residents_count) : 1;
      const stmt = db.prepare('INSERT INTO households (address, area, residents_count) VALUES (?, ?, ?)');
      const result = stmt.run(address, area, residentsCount);
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  app.delete('/api/households/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM households WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  // Waste Bins
  app.get('/api/waste-types', (req, res) => {
    const data = db.prepare('SELECT * FROM waste_types').all();
    res.json(data);
  });

  app.get('/api/bins', (req, res) => {
    const data = db.prepare(`
      SELECT b.*, h.address as household_address, t.name as type_name 
      FROM waste_bins b 
      LEFT JOIN households h ON b.household_id = h.id 
      LEFT JOIN waste_types t ON b.waste_type_id = t.id
      ORDER BY b.id DESC
    `).all();
    res.json(data);
  });

  app.post('/api/bins', (req, res) => {
    console.log('POST /api/bins', req.body);
    const { size, status, household_id, waste_type_id } = req.body;
    try {
      if (!size) throw new Error('Size is required');
      const householdId = (household_id && household_id !== '') ? Number(household_id) : null;
      const wasteTypeId = (waste_type_id && waste_type_id !== '') ? Number(waste_type_id) : null;
      const stmt = db.prepare('INSERT INTO waste_bins (size, status, installation_date, household_id, waste_type_id) VALUES (?, ?, CURRENT_DATE, ?, ?)');
      const result = stmt.run(size, status || 'Empty', householdId, wasteTypeId);
      console.log('Bin added successfully:', result.lastInsertRowid);
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (error: any) {
      console.error('Error adding bin:', error.message);
      res.status(400).json({ success: false, error: error.message });
    }
  });

  app.delete('/api/bins/:id', (req, res) => {
    try {
      db.prepare('DELETE FROM waste_bins WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  // Logistics (Vehicles & Drivers)
  app.get('/api/logistics', (req, res) => {
    const vehicles = db.prepare(`
      SELECT v.*, d.name as driver_name, d.phone as driver_phone, d.license_number 
      FROM collection_vehicles v 
      LEFT JOIN drivers d ON v.driver_id = d.id
    `).all();
    const drivers = db.prepare('SELECT * FROM drivers').all();
    const schedules = db.prepare(`
      SELECT s.*, v.vehicle_number 
      FROM collection_schedules s 
      JOIN collection_vehicles v ON s.vehicle_id = v.id
    `).all();
    res.json({ vehicles, drivers, schedules });
  });

  // Operations (Records, Stations, Centers)
  app.get('/api/operations', (req, res) => {
    const records = db.prepare(`
      SELECT r.*, v.vehicle_number, ts.location as station_location 
      FROM collection_records r 
      JOIN collection_vehicles v ON r.vehicle_id = v.id 
      JOIN transfer_stations ts ON r.station_id = ts.id
      ORDER BY r.collection_date DESC
    `).all();
    const stations = db.prepare('SELECT * FROM transfer_stations').all();
    const centers = db.prepare('SELECT * FROM recycling_centers').all();
    res.json({ records, stations, centers });
  });

  // Finance
  app.get('/api/finance', (req, res) => {
    const data = db.prepare(`
      SELECT p.*, h.address as household_address 
      FROM payments_fines p 
      JOIN households h ON p.household_id = h.id
      ORDER BY p.id DESC
    `).all();
    res.json(data);
  });

  app.post('/api/finance/pay/:id', (req, res) => {
    try {
      db.prepare('UPDATE payments_fines SET status = \'Paid\' WHERE id = ?').run(req.params.id);
      res.json({ success: true });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  // Complaints
  app.get('/api/complaints', (req, res) => {
    const data = db.prepare(`
      SELECT comp.*, c.name as citizen_name 
      FROM complaints comp 
      LEFT JOIN citizens c ON comp.citizen_id = c.id
      ORDER BY comp.id DESC
    `).all();
    res.json(data);
  });

  app.post('/api/complaints', (req, res) => {
    console.log('POST /api/complaints', req.body);
    const { type, description, citizen_id, urgency, date_filed, time_filed, proof } = req.body;
    try {
      if (!type) throw new Error('Complaint type is required');
      const citizenId = (citizen_id && citizen_id !== '') ? Number(citizen_id) : null;
      const stmt = db.prepare('INSERT INTO complaints (type, description, citizen_id, status, date_filed) VALUES (?, ?, ?, \'Open\', ?)');
      const result = stmt.run(
        type, 
        `${description || ''} | Urgency: ${urgency || 'Medium'} | Time: ${time_filed || ''} | Proof: ${proof || 'None'}`, 
        citizenId, 
        date_filed || new Date().toISOString().split('T')[0]
      );
      console.log('Complaint added successfully:', result.lastInsertRowid);
      res.json({ success: true, id: result.lastInsertRowid });
    } catch (error: any) {
      console.error('Error adding complaint:', error.message);
      res.status(400).json({ success: false, error: error.message });
    }
  });

  // Admin
  app.get('/api/admins', (req, res) => {
    const data = db.prepare('SELECT * FROM admins').all();
    res.json(data);
  });

  // Auth
  app.post('/api/signup', (req, res) => {
    const { name, email, phone, login_id, password } = req.body;
    try {
      const stmt = db.prepare('INSERT INTO admins (name, role, login_id, password, email, phone) VALUES (?, \'Admin\', ?, ?, ?, ?)');
      const result = stmt.run(name, login_id, password, email, phone);
      res.json({ success: true, user: { id: result.lastInsertRowid, name, role: 'Admin', login_id } });
    } catch (error: any) {
      res.status(400).json({ success: false, error: error.message });
    }
  });

  app.post('/api/login', (req, res) => {
    const { login_id, password } = req.body;
    const admin = db.prepare('SELECT * FROM admins WHERE login_id = ? AND password = ?').get(login_id, password);
    if (admin) {
      res.json({ success: true, user: admin });
    } else {
      res.status(401).json({ success: false, error: 'Invalid Login ID or Password' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static('dist'));
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
